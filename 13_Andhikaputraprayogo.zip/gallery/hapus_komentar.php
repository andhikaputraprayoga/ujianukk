<!-- hapus_komentar.php -->

<?php
    session_start();
    if (!isset($_SESSION['userid'])) {
        header("location: login.php");
    }

    include "koneksi.php";

    $komentarid = $_GET['id'];

    $deleteQuery = "DELETE FROM komentarfoto WHERE komentarid='$komentarid'";
    $result = mysqli_query($conn, $deleteQuery);

    if ($result) {
        echo "Komentar berhasil dihapus. ";
    } else {
        echo "Error menghapus komentar: " . mysqli_error($conn);
    }
    header("location:komentar.php");
?>
