<?php

function editComment($file_path, $old_comment, $new_comment) {
    // Baca konten file
    $content = file_get_contents($file_path);

    // Ganti komentar lama dengan komentar baru
    $content = str_replace($old_comment, $new_comment, $content);

    // Tulis kembali konten ke file
    file_put_contents($file_path, $content);

    echo "Komentar berhasil diubah.";
}

// Contoh penggunaan
$file_path = 'example.txt'; // Ganti dengan path file yang sesuai
$old_comment = '# Komentar lama';
$new_comment = '# Komentar baru';
editComment($file_path, $old_comment, $new_comment);

?>